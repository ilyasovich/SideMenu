//
//  Protocols.swift
//  SlideMenu
//
//  Created by Aman ILYASOVICH on 5.04.2019.
//  Copyright © 2019 Aman ILYASOVICH. All rights reserved.
//

protocol HomeControllerDelegate {
    func handleMenuToggl(forMenuOption MenuOption: MenuOption?)
}
